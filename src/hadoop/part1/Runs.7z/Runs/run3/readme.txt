The 2 longest words in run2.
input - the same as run2.